package io.matty.wrike;

public class WrikeCfg {
    public static final String clientID = "";
    public static final String clientSecret = "";
    public static final String callbackUri = "";
}
